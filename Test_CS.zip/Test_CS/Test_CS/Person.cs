﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_CS
{
    internal class Person
    {

        private string _firstname;
        private string _secondname;
        private DateTime _birthday;
        private char _gender;
        private byte _weigth;
        private byte _height;

        public string Firstname 
        { 
            get => _firstname;
            set => _firstname = value;
        }
        public string Secondname 
        { 
            get => _secondname;
            set => _secondname = value;
        }
        public DateTime Birthday 
        {
            get => _birthday;
            set => _birthday = value;
        }
        public char Gender 
        {
            get => _gender;
            set => _gender = value;
        }
        public byte Weigth 
        {
            get => _weigth;
            set => _weigth = value;
        }

        public byte Height
        {
            get => _height;
            set => _height = value;
        }
        public Person(string firstname, string secondname, DateTime birtday, char gender, byte weigth, byte height)
        {
            _firstname = firstname;
            _secondname = secondname;
            _birthday = birtday;
            _gender = gender;
            _weigth = weigth;
            _height = height;
        }
        public Person(): this(String.Empty, String.Empty, DateTime.MinValue, Char.MinValue, byte.MinValue, byte.MinValue) { }

        public bool IsOlder(int age)
        {
            return GetAge() > age ? true : false;
        }
        public int GetAge()
        {
            int age = DateTime.Today.Year - _birthday.Year;
            return _birthday.Month > DateTime.Today.Month ? age - 1 : age;
        }

        protected Person CreatePerson(Person person)
        {
            Console.WriteLine("Введите имя: ");
            person._firstname = Console.ReadLine();
            Console.WriteLine("Введите фамилию: ");
            person._secondname = Console.ReadLine();
            Console.WriteLine("Введите дату рождения: (dd.mm.yyyy)");
            person._birthday = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("Введите пол: (м/ж)");
            person._gender = char.Parse(Console.ReadLine());
            Console.WriteLine("Введите вес: ");
            person._weigth = byte.Parse(Console.ReadLine());
            Console.WriteLine("Введите рост: ");
            person._height = byte.Parse(Console.ReadLine());
            return person;
        }
    }
}
